import streamlit as st
from streamlit_option_menu import option_menu

# background style

page_bg_img = """
<style>
[data-testid="stAppViewContainer"] {
background: linear-gradient(180deg, rgba(23, 31, 138, 0.3) 0%, rgba(146, 151, 184, 0.3) 100%);
background-size: cover;
}

[data-testid="stSidebar"] {
backgroung-image: url("data:imagejpg;base64,{img}");
background-size: cover;
"""

st.markdown(page_bg_img, unsafe_allow_html=True)



# ---- HEADER SECTION ----
st.markdown(
    """
    <h1 style="text-align: center;">🚗 RENTAL MOMO 🏍️</h1>
    <h3 style="text-align: center;">Hi, Customer •ᴗ•</h3>
    <h3 style="text-align: center;">Selamat datang di aplikasi Sewa Kendaraan</h3>
    """,
    unsafe_allow_html=True,
)

st.sidebar.success("select a page above")

with st.container():
    st.write("Aplikasi ini digunakan untuk menyewa kendaraan dengan mudah, cepat, dan terpercaya. Silakan pilih jenis kendaraan yang Anda inginkan, lalu isi form pemesanan Anda.")
    st.write("---")

# ---- WHAT WE DO ----
with st.container():
    left_column, right_column = st.columns(2)
    with left_column:
        st.subheader("Kendaraan Yang Kami Rekomendasikan")

    selected = option_menu(
    menu_title= None,
    options=["Mobil", "Motor"],
    icons=["car-front", "bicycle"],
    menu_icon="cast",
    default_index=0,
    orientation="horizontal",
    styles={
                "container": {"padding": "0!important", "background-color": "#fafafa"},
                "icon": {"color": "orange", "font-size": "15px"},
                "nav-link": {
                    "font-size": "15px",
                    "text-align": "center",
                    "margin": "0px",
                    "--hover-color": "#eee",
                },
                "nav-link-selected": {"background-color": "#193153"},
            },
    )
    


    if selected == "Mobil":
        st.write(f" Kami memiliki berbagai macam pilihan kendaraan yang siap untuk Anda sewa. silahkan eksplor katalog ")
        cols1, cols2 = st.columns(2)
        with cols1:
            st.subheader("Mini Cooper")
            st.image("img/miniCooper.jpg", caption="Contoh Mobil", width=150)  
            st.text("★ 4.8/5")
        with cols2:
            st.subheader("Brio")
            st.image("img/brio.jpg", caption="Contoh Mobil", width=150)  
            st.text("★ 4.9/5")

    if selected == "Motor":
        st.write(f" Beberapa motor yang kami rekomendasikan")
        cols1, cols2 = st.columns(2)
        with cols1:
            st.subheader("Vespa Metik")
            st.image("img/vesmet.jpg", caption="Contoh Motor", width=150) 
            st.text("★ 4.8/5")
        with cols2:
            st.subheader("Vario")
            st.image("img/vario.jpg", caption="Contoh Motor", width=150) 
            st.text("★ 4.7/5")
        

# ---- INFORMASI KONTAK ----
st.subheader("Hubungi Kami!")
st.write("Jika Anda ingin bertanya lebih lanjut atau ada masalah yang perlu dibahas, Anda dapat menghubungi kami melalui informasi berikut:")
st.write("**Email:** support@rentalmomo.com")
st.write("**Telepon:** +62 812-3456-7890")
st.write("**Alamat:** Jalan Raya No. 123, Jakarta")