import streamlit as st
from streamlit_option_menu import option_menu
# Kelas Kendaraan
class Kendaraan:
    def __init__(self, merk, tahun, cc, kapasitas_bensin, kursi, harga_per_hari, gambar):
        self.merk = merk
        self.tahun = tahun
        self.cc = cc
        self.kapasitas_bensin = kapasitas_bensin
        self.kursi = kursi
        self.harga_per_hari = harga_per_hari
        self.gambar = gambar
        
    def info_kendaraan(self):
        return (f"Tahun: {self.tahun}\nCC: {self.cc}\nKapasitas Bensin: {self.kapasitas_bensin}\nHarga per Hari: Rp{self.harga_per_hari}"
        )
# List Kendaraan
motor_list = [
    Kendaraan("Vario 150", "2020", "150cc", "5.5 Liter", "2 kursi", "120.000", "img/vario.jpg"),
    Kendaraan("Aerox 155 VVA", "2018", "155cc", "5 Liter", "7 kursi", "150.000", "img/aerox.jpg"),
    Kendaraan("NMAX", "2018", "155cc", "7.1 Liter", "2 kursi", "180.000", "img/nmax.jpg"),
    Kendaraan("Vespa Sprint 150", "2019", "150cc", "7 Liter", "2 kursi", "225.000", "img/vesmet.jpg"),
    Kendaraan("Beat", "2025", "109.5cc", "4.2 Liter", "2 kursi", "150.000", "img/beat.png"),
]

mobil_list = [
    Kendaraan("Hyundai Santa Fe Hybrid", "2025", "1.600cc Turbo", "85 Liter", "7 kursi", "2.500.000", "img/hyundai.jpg"),
    Kendaraan("KIA Carnival", "2024", "2.200cc Turbo", "85 Liter", "7 kursi", "1.300.000", "img/kia.jpg"),
    Kendaraan("Toyota Hiace Premio", "2024", "2.800cc Turbo", "80 Liter", "15 kursi", "3.000.000", "img/hiace.jpg"),
    Kendaraan("Kijang Innova Zenix Hybrid Q", "2024", "1987cc", "72 Liter", "7 kursi", "2.350.000", "img/inova.jpg"),
    Kendaraan("Mini Cooper Clubman", "2024", "1900cc", "48 Liter", "5 kursi", "2.500.000", "img/miniCooper.jpg"),
    Kendaraan("Brio RS", "2023", "1199cc", "35 Liter", "5 kursi", "750.000", "img/brio.jpg"),
]

# Streamlit Sidebar
st.title ("Daftar kendaraan MOMO")

# Pilihan menu dengan ikon
kategori = option_menu(
    menu_title=None,  # Judul menu bisa dihilangkan
    options=["Mobil", "Motor"],  # Pilihan menu
    icons=["car-front", "bicycle"],  # Ikon untuk masing-masing menu
    menu_icon="cast",  # Ikon untuk menu
    default_index=0,  # Indeks menu default yang terpilih
    orientation="horizontal",  # Menampilkan menu secara horizontal
    styles={
        "container": {"padding": "0!important", "background-color": "#fafafa"},
        "icon": {"color": "orange", "font-size": "15px"},
        "nav-link": {
            "font-size": "15px",
            "text-align": "center",
            "margin": "0px",
            "--hover-color": "#eee",
        },
        "nav-link-selected": {"background-color": "#193153"},
    },
)

# Menampilkan kendaraan berdasarkan kategori
if kategori == "Motor":
    cols = st.columns(2)  # Membuat 2 kolom untuk menampilkan gambar secara horizontal
    for i, kendaraan in enumerate(motor_list):
        with cols[i % 2]:
            st.subheader(kendaraan.merk)
            st.image(kendaraan.gambar, width=150)  # Menampilkan gambar
            st.text(kendaraan.info_kendaraan())  # Menampilkan informasi kendaraan

elif kategori == "Mobil":
    cols = st.columns(2)  # Membuat 2 kolom untuk menampilkan gambar secara horizontal
    for i, kendaraan in enumerate(mobil_list):
        with cols[i % 2]:
            st.subheader(kendaraan.merk)
            st.image(kendaraan.gambar, width=150)  # Menampilkan gambar
            st.text(f"Kapasitas: {kendaraan.kursi}")
            st.text(kendaraan.info_kendaraan())
