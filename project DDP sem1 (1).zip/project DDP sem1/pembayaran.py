import streamlit as st


class Pembayaran:
    @staticmethod
    def tampilkan_metode_pembayaran():
        """
        Menampilkan pilihan metode pembayaran
        :return: Pilihan metode pembayaran yang dipilih
        """
        pembayaran = st.radio(
            "Pilih metode pembayaran:",
            ["Transfer Bank", "E-Wallet", "Bayar di Tempat (COD)"]
        )
        return pembayaran

    @staticmethod
    def tampilkan_detail_transfer_bank():
        """
        Menampilkan detail untuk pembayaran melalui Transfer Bank
        """
        st.text("Silakan transfer ke rekening berikut:")
        st.text("Bank: BCA\nNomor Rekening: 123-456-7890 A.n Rental Momo")

    @staticmethod
    def tampilkan_detail_ewallet():
        """
        Menampilkan detail untuk pembayaran melalui E-Wallet
        """
        st.text("Pilih aplikasi E-Wallet yang ingin Anda gunakan:")
        ewallet = st.radio("Pilih E-Wallet:", ["GoPay", "OVO", "DANA", "LinkAja"])
        st.text(f"Silakan transfer ke {ewallet} dengan nomor pengguna: 0898xxxxxxx")

    @staticmethod
    def tampilkan_detail_cod():
        """
        Menampilkan detail untuk pembayaran melalui COD
        """
        st.text("Pembayaran akan dilakukan saat pengambilan kendaraan di lokasi.")

# Mendapatkan pilihan metode pembayaran dari pengguna
pembayaran = Pembayaran.tampilkan_metode_pembayaran()

if pembayaran == "Transfer Bank":
    Pembayaran.tampilkan_detail_transfer_bank()
elif pembayaran == "E-Wallet":
    Pembayaran.tampilkan_detail_ewallet()
elif pembayaran == "Bayar di Tempat (COD)":
    Pembayaran.tampilkan_detail_cod()
