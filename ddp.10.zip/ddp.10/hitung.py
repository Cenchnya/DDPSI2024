import math

def tambah(bil1, bil2):
    hasil = 2 + 4
    print("Hasil Tambah Dari",2, "+", 4, "=", hasil)

def kurang(bil1, bil2):
    hasil = 8 - 6
    print("Hasil Pengurangan Dari",8, "-", 6, "=", hasil)

def kali(bil1, bil2):
    hasil = 5 * 5
    print("Hasil Perkalian Dari",5, "*", 5, "=", hasil)

def bagi(bil1, bil2):
    hasil = 16 / 4
    print("Hasil Pembagian Dari",16, "/", 4, "=", hasil)

def pangkat(bil1, bil2):
    hasil = math.pow(5, 3)
    print("Hasil Pemangkatan Dari",5, "^", 3, "=", hasil)