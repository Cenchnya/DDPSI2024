import streamlit as st
import pandas as pd

st.title("Riwayat Pemesanan")

# Mengecek jika ada data dalam session_state
if "riwayat_pemesanan" not in st.session_state:
    st.session_state.riwayat_pemesanan = []  # Inisialisasi list riwayat pemesanan

# Mengecek apakah ada pemesanan baru
if "my_input" in st.session_state:
    # Ambil data pemesanan terbaru
    data = st.session_state["my_input"]
    
    # Menambahkan data pemesanan baru ke dalam riwayat pemesanan
    st.session_state.riwayat_pemesanan.append(data)
    
    # Hapus 'my_input' setelah ditambahkan ke riwayat
    del st.session_state["my_input"]

# Menampilkan seluruh riwayat pemesanan dalam bentuk DataFrame
if st.session_state.riwayat_pemesanan:
    df = pd.DataFrame(st.session_state.riwayat_pemesanan)
    st.table(df)
else:
    st.write("Belum ada riwayat pemesanan.")
