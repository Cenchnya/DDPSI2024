#bangun datar
import BangunDatar

BangunDatar.l_persegi(4)
BangunDatar.l_persegi_panjang(8,5)
BangunDatar.l_segitiga(2,10)
BangunDatar.l_lingkaran(3)
BangunDatar.l_jajargenjang(12,17)

#hitung
import hitung

hitung.tambah(4, 8)
hitung.kurang(6, 8)
hitung.kali(7, 9)
hitung.bagi(24, 6)
hitung.pangkat(7, 5)

#bangun ruang
import BangunRuang

BangunRuang.l_balok(6,7,4)
BangunRuang.l_kubus(10)
BangunRuang.l_tabung(8,6)
BangunRuang.l_limas_segitiga(6,9)
BangunRuang.l_prisma_segitiga(6,8)