import streamlit as st
from datetime import datetime, timedelta
from pembayaran import Pembayaran
from katalog import motor_list, mobil_list

class SewaKendaraan:
    def __init__(self):
        # Inisialisasi session state jika belum ada
        if "step" not in st.session_state:
            st.session_state.step = 0  # Step 0: Halaman awal (pilih kendaraan)

        # Data kendaraan dan penyewaan yang akan disimpan dalam session state
        self.kendaraan_terpilih = None
        self.lama_sewa = 0
        self.total_harga = 0
        self.tanggal_mulai = None
        self.tanggal_selesai = None
        self.metode_pengambilan = None
        # Gunakan st.session_state untuk menyimpan nama dan nomor telepon
        if "nama_pelanggan" not in st.session_state:
            st.session_state.nama_pelanggan = ""  # Default jika belum ada
        if "no_telp" not in st.session_state:
            st.session_state.no_telp = ""  # Default jika belum ada

    def pilih_kendaraan(self):
        """Langkah 0: Pilih kendaraan dan input durasi sewa"""
        st.title("Sewa Kendaraan")
        st.subheader("Pilih kendaraan yang ingin Anda sewa!")

        # Pilihan kendaraan
        jenis_kendaraan = st.selectbox("Pilih jenis kendaraan:", ["Motor", "Mobil"])

        # Menampilkan daftar kendaraan berdasarkan pilihan
        if jenis_kendaraan == "Motor":
            kendaraan_terpilih = st.selectbox("Pilih motor:", motor_list, format_func=lambda x: x.merk)
        else:
            kendaraan_terpilih = st.selectbox("Pilih mobil:", mobil_list, format_func=lambda x: x.merk)

        if kendaraan_terpilih:
            self.kendaraan_terpilih = kendaraan_terpilih
            st.image(kendaraan_terpilih.gambar, caption=f"{kendaraan_terpilih.merk}", width=150)

            lama_sewa = st.number_input("Berapa hari Anda ingin menyewa kendaraan ini?", min_value=1, step=1)
            self.lama_sewa = lama_sewa

            if lama_sewa <= 0:
                st.error("Durasi sewa harus lebih dari 0 hari.")
                return

            tanggal_mulai = st.date_input("Pilih tanggal mulai penyewaan:", min_value=datetime.now().date())
            self.tanggal_mulai = tanggal_mulai

            tanggal_selesai = tanggal_mulai + timedelta(days=lama_sewa)
            self.tanggal_selesai = tanggal_selesai

            # Menghitung harga
            try:
                harga_per_hari = int(kendaraan_terpilih.harga_per_hari.replace(".", "").replace("Rp", "").strip())
            except ValueError:
                st.error("Harga per hari kendaraan tidak valid.")
                return

            total_harga = lama_sewa * harga_per_hari
            self.total_harga = total_harga
            st.write(f"Total harga untuk {lama_sewa} hari: Rp{total_harga:,}")
            st.write(f"Tanggal penyewaan: {tanggal_mulai.strftime('%d-%m-%Y')} hingga {tanggal_selesai.strftime('%d-%m-%Y')}")

            if st.button("Next"):
                st.session_state.step = 1

    def input_data_pribadi(self):
        """Langkah 1: Input data pribadi dan metode pengambilan"""
        if st.session_state.step == 1:
            pengambilan = st.radio("Pilih metode pengambilan kendaraan:", ["Diantar", "Diambil"])
            st.session_state.nama_pelanggan = st.text_input("Masukkan Nama:", st.session_state.nama_pelanggan)
            st.session_state.no_telp = st.text_input("Masukkan Nomor Telepon:", st.session_state.no_telp)

            if pengambilan == "Diantar":
                jam_antar = st.time_input("Masukkan Jam Pengantaran:")
                lokasi_antar = st.text_input("Masukkan Alamat Pengantaran:")
            else:
                jam_ambil = st.time_input("Masukkan Jam Pengambilan:")

            if st.button("Pilih Metode Pembayaran"):
                if not st.session_state.nama_pelanggan or not st.session_state.no_telp:
                    st.error("Nama dan nomor telepon wajib diisi.")
                elif pengambilan == "Diantar" and not lokasi_antar:
                    st.error("Silakan masukkan alamat pengantaran.")
                else:
                    if pengambilan == "Diantar":
                        metode_pengambilan = f"Diantar ke alamat {lokasi_antar} pada jam {jam_antar}"
                    else:
                        metode_pengambilan = f"Diambil pada jam {jam_ambil}"

                    self.metode_pengambilan = metode_pengambilan
                    st.session_state.step = 2

    def pilih_metode_pembayaran(self):
        """Langkah 2: Pilihan metode pembayaran"""
        if st.session_state.step == 2:
            metode_pembayaran = Pembayaran.tampilkan_metode_pembayaran()

            if metode_pembayaran == "Transfer Bank":
                Pembayaran.tampilkan_detail_transfer_bank()
            elif metode_pembayaran == "E-Wallet":
                Pembayaran.tampilkan_detail_ewallet()
            elif metode_pembayaran == "Bayar di Tempat (COD)":
                Pembayaran.tampilkan_detail_cod()

            if st.button("Sewa Kendaraan"):
                st.success(f"Halo {st.session_state.nama_pelanggan}, Anda telah memilih untuk menyewa {self.kendaraan_terpilih.merk} selama {self.lama_sewa} hari. Total harga: Rp{self.total_harga:,}.")
                st.session_state["my_input"] = {
                    "kendaraan": self.kendaraan_terpilih.merk,
                    "lama sewa": f"{self.lama_sewa} hari",
                    "Tanggal": self.tanggal_mulai,
                    "Total Harga": f"Rp{self.total_harga:,}",
                    "metode pembayaran": metode_pembayaran
                }
                st.balloons()
                st.write("Terima kasih telah menggunakan layanan kami!")

# Menjalankan aplikasi
def main():
    sewa_kendaraan = SewaKendaraan()

    # Langkah-langkah aplikasi berdasarkan step
    sewa_kendaraan.pilih_kendaraan()  # Langkah 0
    sewa_kendaraan.input_data_pribadi()  # Langkah 1
    sewa_kendaraan.pilih_metode_pembayaran()  # Langkah 2

# Memanggil fungsi utama
if __name__ == "__main__":
    main()
