import streamlit as st
import pandas as pd  # Pastikan pandas diimpor

st.title("Riwayat Pemesanan")

# Mengecek jika ada data dalam session_state
if "my_input" in st.session_state:
    # Ambil data dari session_state
    data = st.session_state["my_input"]

    # Mengubah data menjadi DataFrame
    df = pd.DataFrame([data])

    # Menampilkan DataFrame sebagai tabel
    st.table(df)
else:
    # Jika tidak ada data dalam session_state
    st.write("Belum ada riwayat pemesanan.")
