import math

def l_balok(p, l, t):
    hitung = 2 * (p*l)+(p*t)+(l*t)
    print(f'luas balok adalah {hitung}')
    
def l_kubus(s):
    hitung = 6 * s * s
    print(f'luas kubus adalah {hitung}')
    
def l_tabung(r, t):
    hitung = 2 * 3,14
    print(f'luas tabung adalah {hitung}')
    
def l_limas_segitiga(a,t):
    hitung = 1/2 * a * t
    print(f'luas limas adalah {hitung}')
    
def l_prisma_segitiga(a,t):
    hitung = 1/2 * a * t
    print(f'luas prisma segitiga adalah {hitung}')